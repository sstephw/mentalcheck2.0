import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fake_market; fake_market.install()
import engine
res = engine.analyze_many(["NVDA", "AAPL", "SPY"])
for s, r in res.items():
    if not r["ok"]:
        print(s, "FAIL", r.get("error")); continue
    v, d = r["valuation"], r["direction"]
    print(s, round(r["info"]["price"],2), v["verdict"], v["upside"] and round(v["upside"],3),
          d["label"], round(d["score"],3), d["certainty"], "IV", r["vol"]["iv"] and round(r["vol"]["iv"],3),
          "ratio", r["vol"]["ratio"] and round(r["vol"]["ratio"],2), "em", r["earn_move"], "pc", r["options"]["pc_oi"] and round(r["options"]["pc_oi"],2),
          "news", len(r["company_news"]), "pol", len(r["political_news"]))
    if s=="NVDA":
        for k,x in d["signals"].items(): print("   ",k, round(x["value"],2), x["detail"])
        for it in r["political_news"]: print("   P", it["relevance"], it["direct"], it["themes"], it["title"])
        print("   next", r["earnings"]["next_date"], r["hint"])

from streamlit.testing.v1 import AppTest
at = AppTest.from_file("../app.py", default_timeout=120)
at.run()
print("exceptions:", [e.value for e in at.exception])
print("warnings:", [w.value for w in at.warning])
print("tabs:", len(at.tabs), "dataframes:", len(at.dataframe), "markdown:", len(at.markdown))
